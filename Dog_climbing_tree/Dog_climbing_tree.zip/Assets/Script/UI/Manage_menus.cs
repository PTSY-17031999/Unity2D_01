using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Manage_menus : MonoBehaviour
{

    public GameObject Panel_play;
   public void Button_Play()
    {
        SceneManager.LoadScene("Lever_1");

    }




}
