﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Manage_Ui_Gameplay : MonoBehaviour
{
    #region Score
    public List<GameObject> Score_Unit;
    public List<GameObject> Score_Dozen;
    public List<GameObject> Score_Hundred;
    #endregion

   

    private void Start()
    {
        // Ẩn toàn bộ các các số thời gian và điểm
        for (int i = 0; i <= Score_Unit.Count - 1; i++)
        {
            Score_Unit[i].SetActive(false);
            Score_Dozen[i].SetActive(false);
            Score_Hundred[i].SetActive(false);

        }
        processing(101, Score_Unit);
    }
    private void Update()
    {
        Change_Score(111);
        
    }

    public void Change_Score(int Score)
    {
        //  name.SetActive(false);

    }

    void processing(int number, List<GameObject> Unit)
    {
        for (int i = 0; i <= Unit.Count - 1; i++)
        {
            Unit[i].SetActive(false);
           // Dozen[i].SetActive(false);
           // Hundred[i].SetActive(false);
            //Thousand[i].SetActive(false);

        }


        if (number > 9999) return;
        
             string A = number.ToString();
             Unit[(int) A[0]].SetActive(true);
            // Dozen[(int)A[1]].SetActive(true);
             //Hundred[(int)A[2]].SetActive(true);


    }
}
